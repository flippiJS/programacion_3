<?php
include_once "./clases/usuario.php";
include_once "./clases/producto.php";

$caso = "";

if(isset($_GET['caso'])){
    $caso = $_GET['caso'];
}
else if(isset($_POST['caso'])){
    $caso = $_POST['caso'];
}

switch($caso){

    case 'crearUsuario':
        Usuario::crearUsuario();
        break;
    case 'login':
        Usuario::login();
        break;
    case 'listarUsuarios':
        Usuario::listarUsuarios();
        break;
    case 'cargarProducto':
        Producto::cargarProducto();
        break;
    case 'listarProductos':
        Producto::listarProductos();
        break;
    case 'listarProductosConParametros':
        Producto::listarProductosConParametros();
        break;
    case 'modificarProducto':
        Producto::modificarProducto();
        break;
    default:
        echo "Debe ingresar un caso válido($caso).";
        break;

}


?>