<?php

class Producto{

    public $id;
    public $nombre;
    public $precio;
    public $imagen;
    public $nombreUsuario;
    public $cantidad;

    public function __construct($id ,$nombre, $precio, $cantidad, $nombreUsuario, $imagen){
        $this->id = $id;
        $this->nombre = $nombre;
        $this->cantidad = $cantidad;
        $this->imagen = $imagen;
        $this->nombreUsuario = $nombreUsuario;
        $this->precio = $precio;
    }

    public function toCSV(){
        return $this->id.";".$this->nombre.";".$this->precio.";".$this->cantidad.";".$this->nombreUsuario.";".$this->imagen.PHP_EOL;
    }

    public function toString(){
        return  'Id: ' . $this->id . ' Nombre: '. $this->nombre . ' Cantidad: ' . $this->cantidad . PHP_EOL .
                'Precio: ' . $this->precio. ' Nombre de Usuario: '. $this->nombreUsuario . ' Ruta Imagen ' . $this->imagen . PHP_EOL;
    }

    // 4- (2 pts.) caso: cargarProducto(post): Se recibe el id, nombre, el precio y la imagen del producto y nombre de
    // usuario y se guardara en el archivo productos.txt. También se debe guardar el nombre de quien lo guardo.

    public static function cargarProducto(){
        //VERIFICAMOS QUE EL METODO SEA POST
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if( isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['cantidad']) && isset($_POST['precio']) &&
                isset($_POST['nombreUsuario']) && isset($_FILES['imagen'])){
 
                $id = $_POST['id'];
                $nombre = $_POST['nombre'];
                $precio = $_POST['precio'];
                $nombreUsuario = $_POST['nombreUsuario'];
                $cantidad = $_POST['cantidad'];

                //ACCIONES SOBRE FOTO, CAMBIO DE NOMBRE Y UBICACION
                $origen = $_FILES["imagen"]["tmp_name"];
                $nombreOriginal = $_FILES["imagen"]["name"];
                $ext = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
                $destinoFoto = "./imagenes/".$id."-".$nombre.".".$ext;
                move_uploaded_file($origen, $destinoFoto);

                //CREO ENTIDAD
                $producto = new Producto($id ,$nombre, $precio, $cantidad, $nombreUsuario, $destinoFoto);
                //SE CREA EL ARRAY DE PROVEEDORES
                $productos = Producto::leerArhivoDeProductos();
                $usuarios = Usuario::leerArchivo();
                
                if(Producto::existeIdEnArchivo($productos, $id)){
                    echo 'Ya existe un producto con ese Id';
                }
                else if(!(Usuario::existeEnArray($usuarios, $nombreUsuario))){
                    echo 'No existe un usuario con ese nombre';
                }
                else{
                    array_push($productos, $producto);
                    Producto::guardarArchivoDeProductos($productos);
                    echo 'Se guardo el producto en la lista';
                }
            }
            else{
                echo "No configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        }
    }

    //VERIFICA SI EXISTE EL PRODUCTO EN LA LISTA
    public static function existeIdEnArchivo($lista,$id){
        foreach($lista as $producto){
            if($producto->id == $id){
                return true;
            }
        }
        return false;
    }

    //CARGA Y RETORNA UN ARRAY CON LOS PRODUCTOS
    public static function leerArhivoDeProductos(){
        $rutaArchivo = './archivos/productos.txt';
        $retorno = array(); //Lo va a devolver con las entidades leidas
        $archivo = fopen($rutaArchivo, 'r');
        do{
            $producto = trim(fgets($archivo));
            if ($producto != "") 
            {
                $producto = explode(';', $producto);
                array_push($retorno, new Producto($producto[0], $producto[1], $producto[2], $producto[3],$producto[4], $producto[5]));
            }
        }while(!feof($archivo));
        fclose($archivo); 
        return $retorno;   
    }

    //GUARDA LA LISTA EN EL ARCHIVO
    public static function guardarArchivoDeProductos($productos){
        $rutaArchivo = './archivos/productos.txt';
        $archivo = fopen($rutaArchivo, 'w');
        foreach($productos as $item){
            fwrite($archivo, $item->toCSV());
        }
        fclose($archivo);
    }

    // 5- (2pts.) caso: listarProductos (get): Se debe devolver los datos de todos los productos, incluida la ruta de la
    // imagen.

    public static function listarProductos(){
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            $productos = Producto::leerArhivoDeProductos();
            echo 'LISTA DE PRODUCTOS' . PHP_EOL;
            foreach($productos as $item){
                echo $item->toString();
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo GET.";
        }
    }

    // 6- (2pts.) caso: listarProductos (get): Se reciben dos parámetros, criterio (producto o usuario) y valor y se
    // devuelven los datos que coincidan con los datos solicitados.

    public static function listarProductosConParametros(){
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_GET['producto'])){
                $nombreProducto = $_GET['producto'];
            }
            else{
                $nombreProducto = "";
            }
            if( isset($_GET['usuario'])){
                $nombreUsuario = $_GET['usuario'];
            }
            else{
                $nombreUsuario = "";
            }  
            echo 'LISTA DE PRODUCTOS'. PHP_EOL . PHP_EOL;
            $buscadosPorProducto = Producto::listarPedidosPorProducto($nombreProducto);
            $buscadosPorUsuario = Producto::listarPedidosPorUsuario($nombreUsuario);
            echo 'PRODUCTOS BUSCADOS POR PRODUCTOS' . PHP_EOL . PHP_EOL;
            foreach($buscadosPorProducto as $item){
                echo $item->toString();
            }
            echo PHP_EOL . 'PRODUCTOS BUSCADOS POR USUARIOS' . PHP_EOL .PHP_EOL;
            foreach($buscadosPorUsuario as $item){
                echo $item->toString();
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo GET.";
        }
    }
 
    public static function listarPedidosPorProducto($producto){
        $lista = Producto::leerArhivoDeProductos();
        $salida = array();
        foreach($lista as $item){
            if(strcasecmp($item->nombre, $producto) == 0){
                array_push($salida, $item);
            }
        }
        return $salida;
    }

    public static function listarPedidosPorUsuario($usuario){
        $lista = Producto::leerArhivoDeProductos();
        $salida = array();
        foreach($lista as $item){
            if(strcasecmp($item->nombreUsuario, $usuario) == 0){
                array_push($salida, $item);
            }
        }
        return $salida;
    }

    // 7.(2 pts.) caso: modificarProducto(post): Debe poder modificar todos los datos del producto, menos id, y se
    // debe cargar una imagen, si ya existía una guardar la foto antigua en la carpeta /backUpFotos , el nombre será id y
    // la fecha.
    
    public static function modificarProducto(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            if( isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['cantidad']) && isset($_POST['precio']) &&
                isset($_POST['nombreUsuario']) && isset($_FILES['imagen'])){
                
                //Variables para modificar
                $id = $_POST['id'];
                $nombre = $_POST['nombre'];
                $precio = $_POST['precio'];
                $nombreUsuario = $_POST['nombreUsuario'];
                $cantidad = $_POST['cantidad'];
                // echo $id." ".$nombre." ".$precio." ".$nombreUsuario." ".$cantidad;
                $productos = Producto::leerArhivoDeProductos();
                //var_dump($productos);
                if(Producto::existeIdEnArchivo($productos, $id)){
                    foreach($productos as $item){
                        if($item->id == $id){
                            $item->nombre = $nombre;
                            $item->precio = $precio;
                            $item->cantidad = $cantidad;
                            $item->nombreUsuario = $nombreUsuario;
                            //BackUpFoto
                            // $origen = $item->imagen;
                            // $ext = explode(".",$origen);
                            // $destinoBack = "./backUpFotos/".$id."-".date("dmyhis").".".$ext;
                            // move_uploaded_file($origen, $destinoBack);
                            // //ACCIONES SOBRE FOTO, CAMBIO DE NOMBRE Y UBICACION
                            // $origenNueva = $_FILES["imagen"]["tmp_name"];
                            // $nombreOriginal = $_FILES["imagen"]["name"];
                            // $ext = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
                            // $destinoFoto = "./imagenes/".$id."-".$nombre.".".$ext;
                            // move_uploaded_file($origen, $destinoFoto);*/
                            Producto::guardarArchivoDeProductos($productos);
                            echo 'Se modifico el producto';
                        }
                    }
                }
                else{
                    echo 'No existe ese producto';
                }
            }
            else{
                echo "No configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        }
    }
}

?>