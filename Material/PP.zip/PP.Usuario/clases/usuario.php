<?php

class Usuario{

    public $nombre;
    public $clave;

    public function __construct($nombre, $clave){
        $this->nombre = $nombre;
        $this->clave = $clave;
    }

    public function toCSV(){
        return $this->nombre . ";" . $this->clave . PHP_EOL;
    }

    public function toString(){
        return  'Nombre: ' . $this->nombre . ' Clave: '.$this->clave . PHP_EOL;
    }

    // 1- (2 pt.) caso: crearUsuario (post): Se deben guardar los siguientes datos: nombre (debe ser único) y clave. Los
    // datos se guardan en el archivo de texto usuarios.txt.

    public static function crearUsuario(){
        //VERIFICAMOS QUE EL METODO SEA POST
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_POST['nombre']) && isset($_POST['clave'])){
                $nombre = $_POST['nombre'];
                $clave = $_POST['clave'];
                //CREO ENTIDAD
                $usuario = new Usuario($nombre, $clave);
                $usuarios = Usuario::leerArchivo();
                //var_dump($usuarios);
                if(Usuario::existeEnArray($usuarios, $nombre)){
                    echo 'Ya existe usuario con ese nombre';
                }
                else{
                    array_push($usuarios, $usuario);
                    // var_dump($usuarios);
                    Usuario::guardarArchivo($usuarios);
                    echo 'Usuario cargado';
                }
            }
            else{
                echo "No configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        }
    }

    //GUARDAR EN ARCHIVO
    public static function guardarArchivo($usuarios){
        $rutaArchivo = './archivos/usuarios.txt';
        $archivo = fopen($rutaArchivo, 'w');
        foreach($usuarios as $item){
            fwrite($archivo, $item->toCSV());
        }
        fclose($archivo);
    }

    //LEER ARCHIVO Y DEVOLVER EL ARRAY DE USUARIOS
    public static function leerArchivo(){
        $rutaArchivo = './archivos/usuarios.txt';
        $retorno = array(); //Lo va a devolver con las entidades leidas
        $archivo = fopen($rutaArchivo, 'r');
        do{
            $usuario = trim(fgets($archivo));
            if ($usuario != "") 
            {
               $usuario = explode(';', $usuario);
                array_push($retorno, new Usuario($usuario[0], $usuario[1]));
            }
        }while(!feof($archivo));
        fclose($archivo); 
        return $retorno;   
    }
        
    //VERIFICAR SI UN USUARIO EXISTE
    public static function existeEnArray($usuarios, $nombre){
        foreach($usuarios as $item){
            if(strcasecmp (($item->nombre), $nombre) == 0){
                return true;
            }
        }
        return false;
    }

    // 2- (2 pts.) caso: login (post): Se recibe nombre y clave, si coincide se retorna true, de lo contrario, informar si el
    // nombre o la clave no es correcta.

    public static function login(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_POST['clave']) && isset($_POST['nombre'])){
                $clave = $_POST['clave'];
                $nombre = $_POST['nombre'];
                $usuarios = Usuario::leerArchivo();
                if(Usuario::existeEnArray($usuarios, $nombre)){
                    $auxiliar = Usuario::retornarUsuario($usuarios, $nombre);
                    if(strcasecmp(($auxiliar->clave), $clave) == 0){
                        echo 'Logueado';
                    }
                    else{
                        echo 'Clave incorrecta';
                    }
                }
                else{
                    echo 'El nombre es incorrecto!';
                }
            }
            else{
                echo "No configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        }
    }

    public static function retornarUsuario($usuarios, $nombre){
        foreach($usuarios as $item){
            if(strcasecmp (($item->nombre), $nombre) == 0){
                return $item;
            }
        }
        return false;
    }

    // 3- (2pt.) caso: listarUsuarios (get): Recibe un nombre y retorna las ocurrencias, si no coincide se debe retornar
    // “No existe xxx” (xxx es lo que se buscó) La búsqueda tiene que ser case insensitive.

    public static function listarUsuarios(){
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_GET['nombre'])){
                $nombre = $_GET['nombre'];
                $usuarios = Usuario::leerArchivo();
                //var_dump($usuarios);
                if(Usuario::existeEnArray($usuarios, $nombre)){
                    $usuarioAuxiliar = Usuario::retornarUsuario($usuarios, $nombre);
                    //var_dump($usuarioAuxiliar);
                    echo $usuarioAuxiliar->toString();
                }
                else{
                    echo 'No existe ' . $nombre;
                }
            }
            else{
                echo "No configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo GET.";
        } 
    }

}

?>