<?php

class Servicio{
    public $id;
    public $tipo;
    public $precio;
    public $demora;

    public function __construct($id, $tipo, $precio, $demora)
    {
        $this->id = $id;
        $this->tipo = $tipo;
        $this->precio = $precio;
        $this->demora = $demora;
    }

    public function toCSV(){
        $sep = ";";
        return $this->id . $sep . $this->tipo . $sep . $this->precio . $sep . $this->demora . PHP_EOL;
    }

    public function toString(){
        return  'Id: ' . $this->id . ' Tipo: '.$this->tipo . ' Precio: ' . $this->precio . ' Demora: ' . $this->demora . PHP_EOL;
    }

    // 3- (1 pts.) caso: cargarTipoServicio(post): Se recibe el nombre del servicio a realizar: id, tipo(de los 10.000km,
    // 20.000km, 50.000km), precio y demora, y se guardara en el archivo tiposServicio.txt.
    public static function cargarTipoServicio(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_POST['id']) && isset($_POST['tipo']) && isset($_POST['precio']) && isset($_POST['demora'])){   
                $id = $_POST['id'];
                if(Servicio::existeServicioEnArchivo($id)){
                    echo 'Ya existe un servicio con el id ' . $id;
                }
                else{
                    $tipo = $_POST['tipo'];
                    if(Servicio::validarTipoDeServicio($tipo)){
                        $precio = $_POST['precio'];
                        $demora = $_POST['demora'];
                        $servicioNuevo = new Servicio($id, $tipo, $precio, $demora);
                        Servicio::guardarServicioEnArchivo($servicioNuevo);
                        echo 'Servicio creado : ' . $servicioNuevo->toString();
                    }
                    else{
                        echo 'El tipo de servicio es incorrecto (50000km - 20000km - 10000km)';
                    }
                }
            }
            else{
                echo "No se configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        }
    }

    //GUARDAR EN ARCHIVO
    public static function guardarServicioEnArchivo($servicio){
        $rutaArchivo = './archivos/tiposServicio.txt';
        $archivo = fopen($rutaArchivo, 'a+');
        fwrite($archivo, $servicio->toCSV());
        fclose($archivo);
    }

    //LEER ARCHIVO Y DEVOLVER EL ARRAY DE SERVICIOS
    public static function leerArchivoDeServicios(){
        $rutaArchivo = './archivos/tiposServicio.txt';
        $retorno = array(); //Lo va a devolver con las entidades leidas
        $archivo = fopen($rutaArchivo, 'r');
        do{
            $servicio = trim(fgets($archivo));
            if ($servicio != ""){
                $servicio = explode(';', $servicio);
                array_push($retorno, new Servicio($servicio[0], $servicio[1],$servicio[2], $servicio[3]));
            }
        }while(!feof($archivo));
        fclose($archivo); 
        return $retorno;   
    }

    //VERIFICAR SI UN SERVICIO EXISTE
    public static function existeServicioEnArchivo($id){
        $servicios = Servicio::leerArchivoDeServicios();
        foreach($servicios as $item){
            if(strcasecmp (($item->id), $id) == 0){
                return true;
            }
        }
        return false;
    }

    //VALIDAR TIPO
    public static function validarTipoDeServicio($tipo){
        if($tipo == 10000 || $tipo == 20000 || $tipo == 50000){
            return true;
        }
        return false;
    }
}

?>