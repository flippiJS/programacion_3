<?php

class Turno{
    public $patente;
    public $fecha;
    public $marca;
    public $modelo;
    public $precio;
    public $tipoServicio;

    public function __construct($patente, $fecha, $marca, $modelo, $precio, $tipoServicio){
        $this->$patente = $patente;
        $this->$fecha = $fecha;
        $this->$marca = $marca;
        $this->$modelo = $modelo;
        $this->$precio = $precio;
        $this->$tipoServicio = $tipoServicio;
    }
    
    public function toCSV(){
        $sep = ";";
        return $this->patente . $sep . $this->fecha . $sep . $this->marca . $sep . $this->modelo . $sep . $this->precio . $sep . $this->tipoDeServicio . PHP_EOL;
    }
    
    public function toString(){
        return  'Patente: ' . $this->patente . ' Fecha: ' . $this->fecha . ' Marca: ' . $this->marca . PHP_EOL . 
                'Modelo: ' . $this->modelo . ' Precio: ' . $this->precio . ' Tipo: ' . $this->tipoDeServicio . PHP_EOL;
    }
    
    // 4- (2pts.) caso: sacarTurno (get): Se recibe patente y fecha (día) y se debe guardar en el archivo turnos.txt, fecha,
    // patente, marca, modelo, precio y tipo de servicio. Si no hay cupo o la materia no existe informar cada caso
    // particular.
    public static function sacarTurno(){
        
    }

}

?>