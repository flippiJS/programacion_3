<?php

class Vehiculo{
    public $marca;
    public $modelo;
    public $patente;
    public $precio;

    function __construct($marca, $modelo, $patente, $precio){
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->patente = $patente;
        $this->precio = $precio;
    }

    public function toCSV(){
        $sep = ";";
        return $this->marca . $sep . $this->modelo . $sep . $this->patente . $sep . $this->precio . PHP_EOL;
    }

    public function toString(){
        return  'Marca: ' . $this->marca . ' Modelo: '.$this->modelo . ' Patente: ' . $this->patente . ' Precio: ' . $this->precio . PHP_EOL;
    }

    // 1- (2 pt.) caso: cargarVehiculo (post): Se deben guardar los siguientes datos: marca, modelo, patente y precio.
    // Los datos se guardan en el archivo de texto vehiculos.txt, tomando la patente como identificador(la patente, no
    // puede estar repetida).
    public static function cargarVehiculo(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_POST['marca']) && isset($_POST['modelo']) && isset($_POST['patente']) && isset($_POST['precio'])){   
                $patente = $_POST['patente'];
                if(Vehiculo::existeVehiculoEnArchivo($patente)){
                    echo 'Ya existe un vehiculo con la patente ' . $patente;
                }
                else{
                    $precio = $_POST['precio'];
                    $marca = $_POST['marca'];
                    $modelo = $_POST['modelo'];
                    $vehiculoNuevo = new Vehiculo($marca, $modelo, $patente, $precio);
                    Vehiculo::guardarVehiculoEnArchivo($vehiculoNuevo);
                    echo 'Vehiculo creado';
                }
            }
            else{
                echo "No se configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        }
    }

    //GUARDAR EN ARCHIVO
    public static function guardarVehiculoEnArchivo($vehiculo){
        $rutaArchivo = './archivos/vehiculos.txt';
        $archivo = fopen($rutaArchivo, 'a+');
        fwrite($archivo, $vehiculo->toCSV());
        fclose($archivo);
    }

    //LEER ARCHIVO Y DEVOLVER EL ARRAY DE VEHICULOS
    public static function leerArchivoDeVehiculos(){
        $rutaArchivo = './archivos/vehiculos.txt';
        $retorno = array(); //Lo va a devolver con las entidades leidas
        $archivo = fopen($rutaArchivo, 'r');
        do{
            $vehiculo = trim(fgets($archivo));
            if ($vehiculo != ""){
                $vehiculo = explode(';', $vehiculo);
                array_push($retorno, new Vehiculo($vehiculo[0], $vehiculo[1],$vehiculo[2], $vehiculo[3]));
            }
        }while(!feof($archivo));
        fclose($archivo); 
        return $retorno;   
    }

    //VERIFICAR SI UN VEHICULO EXISTE
    public static function existeVehiculoEnArchivo($patente){
        $vehiculos = Vehiculo::leerArchivoDeVehiculos();
        foreach($vehiculos as $item){
            if(strcasecmp (($item->patente), $patente) == 0){
                return true;
            }
        }
        return false;
    }

    // 2- (2pt.) caso: consultarVehiculo (get): Se ingresa marca, modelo o patente, si coincide con algún registro del
    // archivo se retorna las ocurrencias, si no coincide se debe retornar “No existe xxx” (xxx es lo que se buscó) La
    // búsqueda tiene que ser case insensitive.
    public static function consultarVehiculo(){
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_GET['parametro'])){
                $buscado = $_GET['parametro'];
                $vehiculos = Vehiculo::leerArchivoDeVehiculos();
                $listaDeVehiculosEncontrados = array();
                foreach($vehiculos as $item){
                    if(strcasecmp($item->marca, $buscado) == 0 || strcasecmp($item->modelo, $buscado) == 0 || strcasecmp($item->patente, $buscado) == 0){
                        array_push($listaDeVehiculosEncontrados, $item);
                    }
                }
                if(sizeof($listaDeVehiculosEncontrados) > 0){
                    foreach($listaDeVehiculosEncontrados as $vehiculo){
                        echo $vehiculo->toString();
                    }
                }
                else{
                    echo 'No existe ' . $buscado;
                }
            }
            else{
                echo 'Debe ingresar un parametro de busqueda';
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo GET.";
        }
    }

}

?>