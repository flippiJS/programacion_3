<?php

include_once "./clases/vehiculo.php";
include_once "./clases/servicio.php";
include_once "./clases/turno.php";

$caso = "";
if(isset($_GET['caso'])){
    $caso = $_GET['caso'];
}
else if(isset($_POST['caso'])){
    $caso = $_POST['caso'];
}

switch($caso){
    case 'cargarVehiculo':
        Vehiculo::cargarVehiculo();
        break;
    case 'consultarVehiculo':
        Vehiculo::consultarVehiculo();
        break;
    case 'cargarTipoServicio':
        Servicio::cargarTipoServicio();
        break;
    case 'sacarTurno':
        Turno::sacarTurno();
        break;
    case 'turnos':
        
        break;
    case 'inscripciones':
        
        break;
    case 'modificarVehiculo':
      
        break;
    case 'vehiculos':
        
        break;
    default:
        echo "Debe ingresar un caso válido($caso).";
        break;
}

?>