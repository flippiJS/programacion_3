<?php

class Proveedor
{
    public $id;
    public $nombre;
    public $foto;
    public $email;
    
    public function __construct($id,$nombre,$email,$foto)
    {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->email = $email;
        $this->foto = $foto;
    }

    public function toJson(){
        return json_encode($this);
    }

    public function toCSV(){
        return $this->id.";".$this->nombre.";".$this->email.";".$this->foto.PHP_EOL;
    }

    public function toString(){
        return  'Id: ' . $this->id. ' Nombre: '.$this->nombre. ' Email: ' . $this->email. ' Foto: ' . $this->foto . PHP_EOL;
    }

    public static function cargarProveedor(){
        //VERIFICAMOS QUE EL METODO SEA POST
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['email']) && isset($_FILES['foto'])){
                
                $id = $_POST['id'];
                $nombre = $_POST['nombre'];
                $email = $_POST['email'];

                //ACCIONES SOBRE FOTO, CAMBIO DE NOMBRE Y HUBICACION
                $origen = $_FILES["foto"]["tmp_name"];
                $nombreOriginal = $_FILES["foto"]["name"];
                $ext = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
                $destinoFoto = "./fotos/".$id."-".$nombre.".".$ext;
                move_uploaded_file($origen, $destinoFoto);

                //CREO ENTIDAD
                $proveedor = new Proveedor($id, $nombre, $email, $destinoFoto);
                //SE CREA EL ARRAY DE PROVEEDORES
                $proveedores = array();
                //AGREGO AL ARRAY
                array_push($proveedores, $proveedor);
                //SI NO EXISTE ESE ID LO AGREGO
                if(Proveedor::existeIdEnArchivo($id)){
                    echo "El id ya existe en el archivo";
                }
                else{
                    Proveedor::guardarArchivo($proveedores);
                    echo "Proveedor cargado con exito!";
                }
            }
            else{
                echo "No configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        }
    }
    
    //GUARDA PROVEEDOR EN ARCHIVO DE TEXTO
    public static function guardarArchivo($proveedores){
        $rutaArchivo = './archivos/proveedores.txt';
        if(file_exists($rutaArchivo)){
            $archivo = fopen($rutaArchivo, 'a');
        }else{
            $archivo = fopen($rutaArchivo, 'w');
        }
        foreach($proveedores as $prov){
            fwrite($archivo, $prov->toCSV());
        }
        fclose($archivo);
    }

    //LEE ARCHIVO DE TEXTO Y DEVUELVE UN ARRAY
    public static function leerArchivo(){
        $rutaArchivo = './archivos/proveedores.txt';
        $retorno = array(); //Deberia devolver un array de proveedores
        $archivo = fopen($rutaArchivo, 'r');
        do{
            $proveedor = trim(fgets($archivo));
            if ($proveedor != "") 
            {
                $proveedor = explode(';', $proveedor);
                array_push($retorno, new Proveedor($proveedor[0], $proveedor[1], $proveedor[2], $proveedor[3]));
            }
        }while(!feof($archivo));
        fclose($archivo); 
        return $retorno;   
    }

    public static function existeIdEnArchivo($id){
        $lista = Proveedor::leerArchivo();
        foreach($lista as $proveedor){
            if($proveedor->id == $id){
                return true;
            }
        }
        return false;
    }

    public static function consultarProveedor(){
         //VERIFICAMOS QUE EL METODO SEA POST
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_GET['nombre'])){
                //nombre a buscar
                $nombre = $_GET['nombre'];
                $contador = 0;
                $lista = Proveedor::leerArchivo();
                foreach($lista as $proveedor){
                    if(strcasecmp($proveedor->nombre, $nombre) == 0){
                        $contador++;
                    }
                }
                if($contador > 0){
                    echo 'Se encontraron ' . $contador . ' proveedores con ese nombre';
                }
                else{
                    echo 'No existe proveedor ' . $nombre;
                }
            }
            else{
                echo "No configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo GET.";
        }
    }

    public static function proveedores(){
        //VERIFICAMOS QUE EL METODO SEA POST
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            $lista = Proveedor::leerArchivo();
            echo 'Proveedores' . PHP_EOL;
            foreach($lista as $proveedor){
                
                echo $proveedor->toString();
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo GET.";
        }
    }

    public static function modificarProveedor(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['email']) && isset($_FILES['foto'])){
                $id = $_POST['id'];
                $nombre = $_POST['nombre'];
                $email = $_POST['email'];
                
                if(Proveedor::existeIdEnArchivo($id)){
                    $lista = Proveedor::leerArchivo();
                    foreach($lista as $prov){
                        if($prov->id == $id){
                            //backUp de foto
                            $fotoAMover = $prov->foto;
                            $extAMover =  pathinfo($fotoAMover, PATHINFO_EXTENSION);
                            $destino = "./backUpFotos/".$id . "_" . date("Ymd").".".$extAMover;
                            copy($fotoAMover, $destino);
                            
                            //ACCIONES SOBRE FOTO, CAMBIO DE NOMBRE Y HUBICACION
                            $origen = $_FILES["foto"]["tmp_name"];
                            $nombreOriginal = $_FILES["foto"]["name"];
                            $ext = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
                            $destinoFoto = "./fotos/".$id."-".$nombre.".".$ext;
                            move_uploaded_file($origen, $destinoFoto);
                            

                            //cambio datos
                            $prov->nombre = $nombre;
                            $prov->email = $email;
                            $prov->foto = $destinoFoto;
                            Proveedor::guardarArchivo($lista);
                            unlink($fotoAMover);
                        }
                    }
                }
                else{
                    echo 'No existe proveedor con ese Id!';
                }                
            }
            else{
                echo "No configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        } 
    }

    public static function buscarProveedorPorId($id){
        
    }
    
 
}

?>