<?php

class Pedido{

    public $producto;
    public $cantidad;
    public $idProveedor;

    public function __construct($id ,$producto, $cantidad){
        $this->producto = $producto;
        $this->cantidad = $cantidad;
        $this->idProveedor = $id;
    }

    public function toCsv(){
        return $this->idProveedor.";".$this->producto.";".$this->cantidad.PHP_EOL;
    }

    public function toString(){
        return  'Id: ' . $this->idProveedor . ' Producto: '.$this->producto . ' Cantidad: ' . $this->cantidad . 'Proveedor: ' . $this->buscarProveedorPorId($this->idProveedor) . PHP_EOL;
    }

    public static function hacerPedido()
    {
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
            if(isset($_POST["idProveedor"]) && isset($_POST["producto"]) && isset($_POST["cantidad"])){
                //hacer pedido
                $idProveedor= $_POST["idProveedor"];
                $producto= $_POST["producto"];
                $cantidad= $_POST["cantidad"]; 
                //SI EXISTE PORV CON ESE ID HAGO EL PEDIDO
                if(Proveedor::existeIdEnArchivo($idProveedor)){
                    if(is_numeric($cantidad)){
                        $pedido = new Pedido($idProveedor, $producto, $cantidad);
                        $pedidos = Pedido::leerArchivo();
                        array_push($pedidos, $pedido);
                        Pedido::guardarArchivo($pedidos);
                        echo 'Pedido guardado!';
                    }
                    else{
                        echo 'No es una cantida valida!';
                    }
                }
                else{
                    echo 'No existe proveedor con ese Id';
                }
            }        
            else{
                echo("No configuraron todas las variables.");
            }
        }
        else{
            echo("ERROR: Se debe llamar con metodo POST.");
        }    
    } 

    public static function guardarArchivo($pedidos){
        $rutaArchivo = './archivos/pedidos.txt';
    
        $archivo = fopen($rutaArchivo, 'w');
     
        foreach($pedidos as $item){
            fwrite($archivo, $item->toCSV());
        }
        fclose($archivo);
    }

    public static function leerArchivo(){
        $rutaArchivo = './archivos/pedidos.txt';
        $retorno = array(); //Deberia devolver un array de pedidos
        $archivo = fopen($rutaArchivo, 'r');
        do{
            $pedido = trim(fgets($archivo));
            if ($pedido != "") 
            {
                $pedido = explode(';', $pedido);
                array_push($retorno, new Pedido($pedido[0], $pedido[1], $pedido[2]));
            }
        }while(!feof($archivo));
        fclose($archivo); 
        return $retorno;   
    }

    public static function listarPedidos(){
        if($_SERVER["REQUEST_METHOD"] == "GET")
        {
            $lista = Pedido::leerArchivo();
            echo 'PEDIDOS' . PHP_EOL;
            foreach($lista as $producto){
                echo $producto->toString();
            }
        }
        else{
            echo("ERROR: Se debe llamar con metodo GET.");
        }  
    }

    public function buscarProveedorPorId($id){
        $lista = Proveedor::leerArchivo();
        $retorno = "";
        foreach($lista as $proveedor){
            if($proveedor->id == $id){
                $retorno = $proveedor->nombre;
            }
        }
        return $retorno;
    }

    public static function listarPedidoProveedor(){
        if($_SERVER["REQUEST_METHOD"] == "GET")
        {
            if(isset($_GET['id'])){
                $id = $_GET['id'];
                $lista = Pedido::buscarPedidos($id);
                if(count($lista) > 0){
                    foreach($lista as $pedido){
                        echo $pedido->toString();
                    }
                }
                else{
                    echo 'No hay pedidos para ese Id';
                }
            }
            else{
                echo 'Falta configurar variale';
            }
        }
        else{
            echo("ERROR: Se debe llamar con metodo GET.");
        }  
    }

    public static function buscarPedidos($id){
        $listaDePedidos = Pedido::leerArchivo();
        $retorno = array();
        foreach($listaDePedidos as $pedido){
            if($pedido->idProveedor == $id){
                array_push($retorno, $pedido);
            }
        }
        return $retorno;
    }
}

?>