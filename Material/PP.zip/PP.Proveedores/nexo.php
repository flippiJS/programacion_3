<?php
include_once "./clases/proveedor.php";
include_once "./clases/pedidos.php";

$caso = "";

if(isset($_GET['caso'])){
    $caso = $_GET['caso'];
}
else if(isset($_POST['caso'])){
    $caso = $_POST['caso'];
}

switch($caso){

    case 'cargarProveedor':
        Proveedor::cargarProveedor();
        break;
    case 'consultarProveedor':
        Proveedor::consultarProveedor();
        break;
    case 'proveedores':
        Proveedor::proveedores();
        break;
    case 'hacerPedido':
        Pedido::hacerPedido();
        break;
    case 'listarPedidos':
        Pedido::listarPedidos();
        break;
    case 'listarPedidoProveedor':
        Pedido::listarPedidoProveedor();
        break;
    case 'modificarProveedor':
        Proveedor::modificarProveedor();
        break;
    default:
        echo "Debe ingresar un caso válido($caso).";
        break;

}


?>