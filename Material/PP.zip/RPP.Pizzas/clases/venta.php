<?php

class Venta{
    public $id;
    public $email;
    public $sabor;
    public $tipo;
    public $cantidad;

    public function __construct($id, $email, $sabor, $tipo, $cantidad){
        $this->id = $id;
        $this->tipo = $tipo;
        $this->cantidad = $cantidad;
        $this->email = $email;
        $this->sabor = $sabor;
    }

    public static function altaVenta(){

    }

    public static function listadoDeVentas(){

    }

    public static function listadoDeVentasConParametro(){
        
    }
}

?>