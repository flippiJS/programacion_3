<?php

class Pizza{
    public $id;
    public $precio;
    public $tipo; // molde piedra
    public $cantidad; //unidades
    public $sabor; // muzza jamon especial
    public $imagen;

    public function __construct($id, $precio, $tipo, $cantidad, $sabor, $imagen){
        $this->id = $id;
        $this->precio = $precio;
        $this->tipo = $tipo;
        $this->cantidad = $cantidad;
        $this->sabor = $sabor;
        $this->imagen = $imagen;
    }

    public static function pizzaCarga(){

    }

    public static function pizzaConsultar(){

    }

    public static function borrarItem(){
        
    }

}

?>