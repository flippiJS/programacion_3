<?php

class Producto{
    public $id;
    public $nombre;
    public $precio;
    public $imagen;
    public $nombreUsuario;
    public $cantidad;
    
    public function __construct($id ,$nombre, $precio, $cantidad, $nombreUsuario, $imagen){
        $this->id = $id;
        $this->nombre = $nombre;
        $this->precio = $precio;
        $this->cantidad = $cantidad;
        $this->nombreUsuario = $nombreUsuario; 
        $this->imagen = $imagen;
    }

    public function toCSV(){
        return $this->id.";".$this->nombre.";".$this->precio.";".$this->cantidad.";".$this->nombreUsuario.";".$this->imagen.PHP_EOL;
    }

    public function toString(){
        return  'Id: ' . $this->id . ' Nombre: '. $this->nombre . ' Precio: ' . $this->precio . PHP_EOL .
                'Cantidad: ' . $this->cantidad . ' Nombre de Usuario: '. $this->nombreUsuario . ' Ruta Imagen ' . $this->imagen . PHP_EOL;
    }

    // 4- (2 pts.) caso: cargarProducto(post): Se recibe el id, nombre, el precio y la imagen del producto y nombre de
    // usuario y se guardara en el archivo productos.txt. También se debe guardar el nombre de quien lo guardo.
    public static function cargarProducto(){
        //VERIFICAMOS QUE EL METODO SEA POST
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if( isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['cantidad']) && isset($_POST['precio']) &&
                isset($_POST['nombreUsuario']) && isset($_FILES['imagen'])){

                $id = $_POST['id'];
                $nombreUsuario = $_POST['nombreUsuario'];
                
                if(Producto::existeProductoEnArchivo($id)){
                    echo 'Ya existe un producto con ese Id';
                }
                else if(!(Usuario::existeUsuarioEnArchivo($nombreUsuario))){
                    echo 'No existe un usuario con ese nombre';
                }
                else{
                    $precio = $_POST['precio'];
                    $nombre = $_POST['nombre'];
                    $cantidad = $_POST['cantidad'];

                    //ACCIONES SOBRE FOTO, CAMBIO DE NOMBRE Y UBICACION
                    $origen = $_FILES["imagen"]["tmp_name"];
                    $nombreOriginal = $_FILES["imagen"]["name"];
                    $ext = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
                    $destinoFoto = "./imagenes/".$id."-".$nombre.".".$ext;
                    move_uploaded_file($origen, $destinoFoto);
                    //CREO ENTIDAD
                    $producto = new Producto($id ,$nombre, $precio, $cantidad, $nombreUsuario, $destinoFoto);
                    Producto::guardarProductoEnArchivo($producto);
                    echo 'Se guardo el producto en el archivo';
                }
            }
            else{
                echo "No se configuraron todas las variables.";
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        }
    }

    //GUARDA PRODUCTO EN LA LISTA
    public static function guardarProductoEnArchivo($producto){
        $rutaArchivo = './archivos/productos.txt';
        $archivo = fopen($rutaArchivo, 'a+');
        fwrite($archivo, $producto->toCsv());
        fclose($archivo);
    }

    //CARGA Y RETORNA UN ARRAY CON LOS PRODUCTOS
    public static function leerArhivoDeProductos(){
        $rutaArchivo = './archivos/productos.txt';
        $retorno = array(); //Lo va a devolver con las entidades leidas
        $archivo = fopen($rutaArchivo, 'r');
        do{
            $producto = trim(fgets($archivo));
            if ($producto != "") 
            {
                $producto = explode(';', $producto);
                array_push($retorno, new Producto($producto[0], $producto[1], $producto[2], $producto[3],$producto[4], $producto[5]));
            }
        }while(!feof($archivo));
        fclose($archivo); 
        return $retorno;   
    }

    //VERIFICA SI EXISTE EL PRODUCTO EN LA LISTA
    public static function existeProductoEnArchivo($id){
        $productos = Producto::leerArhivoDeProductos();
        foreach($productos as $producto){
            if($producto->id == $id){
                return true;
            }
        }
        return false;
    }

    // 5- (2pts.) caso: listarProductos (get): Se debe devolver los datos de todos los productos, incluida la ruta de la
    // imagen.
    public static function listarProductos(){
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            $productos = Producto::leerArhivoDeProductos();
            echo 'LISTA DE PRODUCTOS' . PHP_EOL . PHP_EOL;
            foreach($productos as $item){
                echo $item->toString();
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo GET.";
        }
    }

    // 6- (2pts.) caso: listarProductos (get): Se reciben dos parámetros, criterio (producto o usuario) y valor y se
    // devuelven los datos que coincidan con los datos solicitados.
    public static function listarProductosConParametros(){
        if($_SERVER['REQUEST_METHOD'] == 'GET'){
            //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
            if(isset($_GET['producto'])){
                $nombreProducto = $_GET['producto'];
            }
            else{
                $nombreProducto = "";
            }
            if( isset($_GET['usuario'])){
                $nombreUsuario = $_GET['usuario'];
            }
            else{
                $nombreUsuario = "";
            }  
            echo 'LISTA DE PRODUCTOS'. PHP_EOL . PHP_EOL;

            echo 'PRODUCTOS BUSCADOS POR PRODUCTOS' . PHP_EOL . PHP_EOL;
            Producto::listarPedidosPorProducto($nombreProducto);
            echo PHP_EOL . 'PRODUCTOS BUSCADOS POR USUARIOS' . PHP_EOL .PHP_EOL;
            Producto::listarPedidosPorUsuario($nombreUsuario);
        }
        else{
            echo "ERROR: Se debe llamar con metodo GET.";
        }
    }
 
    public static function listarPedidosPorProducto($producto){
        $lista = Producto::leerArhivoDeProductos();
        foreach($lista as $item){
            if(strcasecmp($item->nombre, $producto) == 0){
                echo $item->toString() . PHP_EOL;
            }
        }
    }

    public static function listarPedidosPorUsuario($usuario){
        $lista = Producto::leerArhivoDeProductos();
        foreach($lista as $item){
            if(strcasecmp($item->nombreUsuario, $usuario) == 0){
                echo $item->toString() . PHP_EOL;
            }
        }
    }

    // 7.(2 pts.) caso: modificarProducto(post): Debe poder modificar todos los datos del producto, menos id, y se debe 
    //cargar una imagen, si ya existía una guardar la foto antigua en la carpeta /backUpFotos , el nombre será id y la fecha.
    public static function modificarProducto(){
        //VERIFICAMOS QUE EL METODO SEA POST
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
           //VERIFICAMOS QUE ESTEN TODAS LAS VARIABLES
           if( isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['cantidad']) && isset($_POST['precio']) &&
              isset($_POST['nombreUsuario']) && isset($_FILES['imagen'])){
               //Variables para modificar
               $id = $_POST['id'];
               
               if(Producto::existeProductoEnArchivo($id)){
                    $nombreUsuario = $_POST['nombreUsuario'];
                    $cantidad = $_POST['cantidad'];
                    $nombre = $_POST['nombre'];
                    $precio = $_POST['precio'];

                    $productos = Producto::leerArhivoDeProductos();

                    foreach($productos as $item){
                        if($item->id == $id){
                            $item->nombre = $nombre;
                            $item->nombreUsuario = $nombreUsuario;
                            $item->precio = $precio;
                            $item->cantidad = $cantidad;

                            //ACCIONES SOBRE FOTO, CAMBIO DE NOMBRE Y UBICACION
                            $origen = $_FILES["imagen"]["tmp_name"];
                            $nombreOriginal = $_FILES["imagen"]["name"];
                            $ext = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
                            $destinoFoto = "./imagenes/".$id."-".$nombre.".".$ext;
                            if(file_exists($destinoFoto)) 
                                copy($destinoFoto,"./backUpFotos/".$item->id."_".date("dmyhis").".".$ext);

                            move_uploaded_file($origen, $destinoFoto);
                            Producto::guardarListaDeProductosEnArchivo($productos);
                            echo "Producto modificado";
                        }
                    }
               }
               else{
                   echo 'No existe el producto en el archivo';
               }
           }    
           else{
              echo "No se configuraron todas las variables.";
           }
       }
       else{
           echo "ERROR: Se debe llamar con metodo POST.";
       }
   }  

    public static function guardarListaDeProductosEnArchivo($productos){
        $rutaArchivo = './archivos/productos.txt';
        $archivo = fopen($rutaArchivo, 'w');
        foreach($productos as $item){
            fwrite($archivo, $item->toCSV());
        }
        fclose($archivo);
    }

    public static function hacerMarcaDeAgua(){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            if(isset($_FILES['foto']) && isset($_FILES['estampa'])){
                //ACCIONES PRIMER FOTO, CAMBIO DE NOMBRE Y UBICACION
                $origenFoto = $_FILES["foto"]["tmp_name"];
                $nombreOriginalFoto = $_FILES["foto"]["name"];
                $ext = pathinfo($nombreOriginalFoto, PATHINFO_EXTENSION);
                $destinoFoto = "./marcaDeAgua/foto.".$ext;
                move_uploaded_file($origenFoto, $destinoFoto);

                //ACCIONES SOBRE ESTAMPA FOTO, CAMBIO DE NOMBRE Y UBICACION
                $origenEstampa = $_FILES["estampa"]["tmp_name"];
                $nombreOriginalEstampa = $_FILES["estampa"]["name"];
                $extEstampa = pathinfo($nombreOriginalEstampa, PATHINFO_EXTENSION);
                $destinoEstampa = "./marcaDeAgua/estampa.".$extEstampa;
                move_uploaded_file($origenEstampa, $destinoEstampa);

                // Cargar la estampa y la foto para aplicarle la marca de agua
                $estampa = imagecreatefrompng($destinoEstampa);
                $im = imagecreatefromjpeg($destinoFoto);

                // Establecer los márgenes para la estampa y obtener el alto/ancho de la imagen de la estampa
                $margen_dcho = 10;
                $margen_inf = 10;
                $sx = imagesx($estampa);
                $sy = imagesy($estampa);

                // Copiar la imagen de la estampa sobre nuestra foto usando los índices de márgen y el
                // ancho de la foto para calcular la posición de la estampa. 
                imagecopymerge($im, $estampa,0,imagesy($im) - $sy, 0, 0, $sx, $sy, 50);

                // Imprimir y liberar memoria
                header('Content-type: image/png');
                imagepng($im, './marcaDeAgua/nueva_imagen.png' );
                imagedestroy($im);

                echo 'Marca de agua creada';
            }
            else{
                echo 'No se configuraron todas las variables';
            }
        }
        else{
            echo "ERROR: Se debe llamar con metodo POST.";
        }
    }

}

?>
